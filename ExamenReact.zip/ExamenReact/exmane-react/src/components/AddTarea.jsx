import React, { useState } from 'react'
import ListaDesplegable from './ListaDesplegable'


function AddTarea({agregarTarea}) {

    const [inputAgregar, setInputAgregar] = useState(``)

    const handleOnChange = (e) => {
        setInputAgregar(e.currentTarget.value)
    }

    const handleSubmit = (e) => {
        e.preventDefault()
        if (inputAgregar.trim() !== ``) {
            agregarTarea(inputAgregar)
            setInputAgregar('')
        }
    }

  return (
    <div style={{margin:20}}>
        <form onSubmit={handleSubmit}>
            <input type="text" value={inputAgregar} onChange={handleOnChange} className='input-agregar'/>
            <button className='btn-agregar'>Agregar Tarea</button>

            <ListaDesplegable/>
        </form>
    </div>
  )
}

export default AddTarea