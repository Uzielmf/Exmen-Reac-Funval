import React, { useState } from 'react'

function ListaDesplegable() {

    const [visible,setvisible] = useState(false)

  return (
    <div className=''>
        <button onClick={()=>{
            setvisible(!visible)
        }}>Lista Desplegable</button>
        <div className={`lista-desplegable ${ visible ? 'isActive' : ''}`}>
        <ul className='lista-desplegada'>
            <li>Todos</li>
            <li>Activas</li>
            <li>Completas</li>
        </ul>
        </div>
    </div>
  )
}

export default ListaDesplegable