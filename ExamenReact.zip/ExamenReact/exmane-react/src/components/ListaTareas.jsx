import React from 'react'
import TareaItem from './TareaItem'



function ListaTareas({tareas, onCompleted, onDeleteTarea}) {
  return (
    <div>
        {
        tareas.map((tarea, key) => (
            <TareaItem key={`tarea -${key}`} tarea = {tarea} onCompleted={onCompleted} onDeleteTarea = {onDeleteTarea}/>
        ))
        }
    </div>
  )
}

export default ListaTareas