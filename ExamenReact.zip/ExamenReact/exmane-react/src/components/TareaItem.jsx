import React from 'react'


function TareaItem({tarea, onCompleted, onDeleteTarea}) {
  
    const estilo = () => {
        return {
        textDecoration: tarea.completed ? 'line-through' : 'none',
        margin: "20px",
        padding: "10px",
        border: "1 px solid #ffffff",
        borderRadius: "40px",
        backgroundColor: "hsl(0, 0%, 100%)"
        }
    }
  
    return (
    <div style={estilo()}>
        <input type="checkbox" checked = {tarea.completed}  onChange={() => onCompleted(tarea.id)}/>
        
        {tarea.task}
        <button className='add-btn' onClick={()=> onDeleteTarea(tarea.id)}>Eliminar trash</button>
    </div>
  )
}

export default TareaItem