import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import data from "./data.json"
import ListaTareas from './components/listaTareas'
import AddTarea from './components/AddTarea'


function App() {
  const [tareas, setTarea ] = useState(data)

  const onCompleted = (id)=> {
    console.log(`tarea numero`,id);

    setTarea(tareas.map((tarea)=>{
      return tarea.id === Number(id) ? {...tarea, completed : !tarea.completed} : {...tarea}
    } ))
  }

  const onDeleteTarea = (id) => {
    setTarea([...tareas].filter(tarea => tarea.id !== id))
    
  }

  const agregarTarea = (nuevaTarea) =>{
        console.log(nuevaTarea);
        let nuevoItem = {id: +new Date(), task: nuevaTarea, completed:false}

        setTarea([...tareas, nuevoItem])
  }
  
  return (
    <>
    <div className='container'>
      <AddTarea agregarTarea = {agregarTarea}/>

      <ListaTareas tareas = {tareas} onCompleted={onCompleted} onDeleteTarea={onDeleteTarea}/>
    
    </div>

    </>
  )
}

export default App
